from django.contrib import admin

from profileapp.models import Profile,Doctor

admin.site.register(Profile)
admin.site.register(Doctor)

